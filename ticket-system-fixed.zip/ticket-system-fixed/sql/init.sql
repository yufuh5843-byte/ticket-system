-- ========================================
-- 高并发火车票抢票系统 - 数据库表设计
-- 设计理念：
-- 1. 用户表：存储用户基本信息
-- 2. 车次表：存储列车基本信息（如G1234次列车）
-- 3. 车次站点表：存储列车经过的站点及顺序（用于计算区间余票）
-- 4. 座位表：存储每个车次的具体座位信息（核心表，用于并发扣减）
-- 5. 订单表：存储用户购票订单
-- ========================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS ticket_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ticket_system;

-- ----------------------------------------
-- 1. 用户表
-- 设计说明：存储用户基本信息，用于身份验证和订单关联
-- ----------------------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID，主键',
    `username` VARCHAR(50) NOT NULL COMMENT '用户名，唯一',
    `password` VARCHAR(100) NOT NULL COMMENT '密码（加密存储）',
    `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
    `id_card` VARCHAR(18) NOT NULL COMMENT '身份证号，唯一',
    `phone` VARCHAR(11) NOT NULL COMMENT '手机号',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态：1-正常 0-禁用',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    UNIQUE KEY `uk_id_card` (`id_card`),
    KEY `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ----------------------------------------
-- 2. 车次表
-- 设计说明：存储列车基本信息，一趟列车对应一条记录
-- ----------------------------------------
DROP TABLE IF EXISTS `t_train`;
CREATE TABLE `t_train` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '车次ID，主键',
    `train_code` VARCHAR(20) NOT NULL COMMENT '车次编号（如G1234）',
    `train_type` TINYINT NOT NULL COMMENT '列车类型：1-高铁 2-动车 3-普快',
    `start_station` VARCHAR(50) NOT NULL COMMENT '始发站',
    `end_station` VARCHAR(50) NOT NULL COMMENT '终点站',
    `start_time` TIME NOT NULL COMMENT '发车时间',
    `end_time` TIME NOT NULL COMMENT '到达时间',
    `total_seats` INT NOT NULL DEFAULT 0 COMMENT '总座位数',
    `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态：1-正常 0-停运',
    `sale_start_time` DATETIME COMMENT '售票开始时间',
    `sale_end_time` DATETIME COMMENT '售票结束时间',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_train_code` (`train_code`),
    KEY `idx_start_station` (`start_station`),
    KEY `idx_end_station` (`end_station`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='车次表';

-- ----------------------------------------
-- 3. 车次站点表
-- 设计说明：存储列车经过的所有站点及顺序
-- 核心作用：用于计算区间票价和判断座位在某区间是否可用
-- 例如：北京->上海，经过济南、南京，则该表有4条记录
-- ----------------------------------------
DROP TABLE IF EXISTS `t_train_station`;
CREATE TABLE `t_train_station` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    `train_id` BIGINT NOT NULL COMMENT '车次ID',
    `station_name` VARCHAR(50) NOT NULL COMMENT '站点名称',
    `station_index` INT NOT NULL COMMENT '站点顺序（从1开始）',
    `arrive_time` TIME COMMENT '到达时间（始发站为null）',
    `depart_time` TIME COMMENT '发车时间（终点站为null）',
    `stay_minutes` INT DEFAULT 2 COMMENT '停留分钟数',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_train_station_index` (`train_id`, `station_index`),
    KEY `idx_train_id` (`train_id`),
    KEY `idx_station_name` (`station_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='车次站点表';

-- ----------------------------------------
-- 4. 座位表（核心表 - 高并发扣减的关键）
-- 设计说明：
-- 1. 每个座位一条记录，记录该座位在各站段的占用情况
-- 2. 使用 seat_segments 字段存储座位占用信息（位图方式）
-- 3. version 字段用于乐观锁，防止超卖
-- 4. 该表是高并发抢票的核心竞争资源
-- 
-- 座位状态说明：
-- seat_segments 使用二进制位表示每个站段的占用情况
-- 例如：北京(1)->济南(2)->南京(3)->上海(4)，共3个站段
-- seat_segments = 0b000 表示座位完全空闲
-- seat_segments = 0b001 表示北京-济南段被占用
-- seat_segments = 0b011 表示北京-济南和济南-南京段被占用
-- ----------------------------------------
DROP TABLE IF EXISTS `t_seat`;
CREATE TABLE `t_seat` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '座位ID，主键',
    `train_id` BIGINT NOT NULL COMMENT '车次ID',
    `carriage_no` INT NOT NULL COMMENT '车厢号',
    `seat_no` VARCHAR(10) NOT NULL COMMENT '座位号（如01A、02B）',
    `seat_type` TINYINT NOT NULL COMMENT '座位类型：1-商务座 2-一等座 3-二等座',
    `seat_segments` INT NOT NULL DEFAULT 0 COMMENT '座位站段占用位图（0表示空闲）',
    `version` INT NOT NULL DEFAULT 0 COMMENT '乐观锁版本号，用于防止超卖',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_train_carriage_seat` (`train_id`, `carriage_no`, `seat_no`),
    KEY `idx_train_id` (`train_id`),
    KEY `idx_seat_type` (`seat_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='座位表（核心并发表）';

-- ----------------------------------------
-- 5. 订单表
-- 设计说明：存储用户购票订单信息
-- 订单状态流转：待支付 -> 已支付 -> 已完成/已取消/已退款
-- ----------------------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '订单ID，主键',
    `order_no` VARCHAR(32) NOT NULL COMMENT '订单号，唯一',
    `user_id` BIGINT NOT NULL COMMENT '用户ID',
    `train_id` BIGINT NOT NULL COMMENT '车次ID',
    `train_code` VARCHAR(20) NOT NULL COMMENT '车次编号（冗余，便于查询）',
    `seat_id` BIGINT NOT NULL COMMENT '座位ID',
    `carriage_no` INT NOT NULL COMMENT '车厢号',
    `seat_no` VARCHAR(10) NOT NULL COMMENT '座位号',
    `seat_type` TINYINT NOT NULL COMMENT '座位类型',
    `start_station` VARCHAR(50) NOT NULL COMMENT '出发站',
    `end_station` VARCHAR(50) NOT NULL COMMENT '到达站',
    `start_station_index` INT NOT NULL COMMENT '出发站序号',
    `end_station_index` INT NOT NULL COMMENT '到达站序号',
    `travel_date` DATE NOT NULL COMMENT '出行日期',
    `price` DECIMAL(10,2) NOT NULL COMMENT '票价',
    `status` TINYINT NOT NULL DEFAULT 0 COMMENT '订单状态：0-待支付 1-已支付 2-已完成 3-已取消 4-已退款',
    `pay_time` DATETIME COMMENT '支付时间',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_order_no` (`order_no`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_train_date` (`train_id`, `travel_date`),
    KEY `idx_status` (`status`),
    KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ----------------------------------------
-- 6. 车次库存缓存表（用于Redis预扣减的本地快照）
-- 设计说明：
-- 1. 用于快速查询余票数量，避免每次都扫描座位表
-- 2. 配合Redis实现高并发下的库存预扣减
-- 3. 定时任务同步Redis与数据库的库存数据
-- ----------------------------------------
DROP TABLE IF EXISTS `t_train_stock`;
CREATE TABLE `t_train_stock` (
    `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '主键',
    `train_id` BIGINT NOT NULL COMMENT '车次ID',
    `travel_date` DATE NOT NULL COMMENT '出行日期',
    `seat_type` TINYINT NOT NULL COMMENT '座位类型',
    `total_stock` INT NOT NULL DEFAULT 0 COMMENT '总库存',
    `available_stock` INT NOT NULL DEFAULT 0 COMMENT '可用库存',
    `version` INT NOT NULL DEFAULT 0 COMMENT '乐观锁版本号',
    `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_train_date_type` (`train_id`, `travel_date`, `seat_type`),
    KEY `idx_travel_date` (`travel_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='车次库存表';

-- ----------------------------------------
-- 初始化测试数据
-- ----------------------------------------

-- 插入测试用户
INSERT INTO `t_user` (`username`, `password`, `real_name`, `id_card`, `phone`) VALUES
('zhangsan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', '张三', '110101199001011234', '13800138001'),
('lisi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH', '李四', '110101199002022345', '13800138002');

-- 插入测试车次：北京->上海的高铁
INSERT INTO `t_train` (`train_code`, `train_type`, `start_station`, `end_station`, `start_time`, `end_time`, `total_seats`, `sale_start_time`, `sale_end_time`) VALUES
('G101', 1, '北京南', '上海虹桥', '07:00:00', '11:30:00', 600, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY));

-- 插入车次站点信息
INSERT INTO `t_train_station` (`train_id`, `station_name`, `station_index`, `arrive_time`, `depart_time`, `stay_minutes`) VALUES
(1, '北京南', 1, NULL, '07:00:00', 0),
(1, '济南西', 2, '08:30:00', '08:32:00', 2),
(1, '南京南', 3, '09:45:00', '09:47:00', 2),
(1, '上海虹桥', 4, '11:30:00', NULL, 0);

-- 插入座位数据（模拟一节车厢，10个二等座）
INSERT INTO `t_seat` (`train_id`, `carriage_no`, `seat_no`, `seat_type`, `seat_segments`) VALUES
(1, 1, '01A', 3, 0),
(1, 1, '01B', 3, 0),
(1, 1, '01C', 3, 0),
(1, 1, '02A', 3, 0),
(1, 1, '02B', 3, 0),
(1, 1, '02C', 3, 0),
(1, 1, '03A', 3, 0),
(1, 1, '03B', 3, 0),
(1, 1, '03C', 3, 0),
(1, 1, '04A', 3, 0);

-- 插入库存数据
INSERT INTO `t_train_stock` (`train_id`, `travel_date`, `seat_type`, `total_stock`, `available_stock`) VALUES
(1, CURDATE(), 3, 10, 10);
