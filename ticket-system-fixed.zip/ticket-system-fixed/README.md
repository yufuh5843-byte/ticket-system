# 🚄 高并发火车票抢票系统

基于 Spring Boot + Redis + MySQL 实现的高并发抢票系统，提供三种并发控制方案，适合作为学习高并发编程的参考项目。

## ✨ 核心设计亮点

### 位图座位算法
用一个 INT 字段的二进制位表示座位的区间占用状态，避免了"每座位每日期一条记录"的数据爆炸问题。

```
北京(1) → 济南(2) → 南京(3) → 上海(4)，共3个站段
seat_segments = 0b000  表示座位完全空闲
seat_segments = 0b001  北京-济南段被占用
seat_segments = 0b011  北京-南京段被占用（中间段购票）
```

### 三种并发控制方案对比

| 方案 | 接口 | 优点 | 适用场景 |
|------|------|------|----------|
| 乐观锁（单次） | `POST /api/ticket/buy` | 简单，无锁开销 | 中低并发 |
| Redis 分布式锁 | `POST /api/ticket/buy-with-lock` | 强一致，适合集群 | 高并发 |
| 乐观锁 + 多候选重试 | `POST /api/ticket/buy-with-optimistic` | 吞吐量高 | 极高并发 |

## 🛠️ 技术栈

- **Spring Boot 2.7.18**
- **MyBatis Plus 3.5.3**
- **Redis**（Lua脚本保证原子性）
- **MySQL 8.0**（乐观锁 version 字段）
- **Hutool**（雪花算法生成订单号）

## 🚀 快速启动

### 环境要求
- JDK 11+
- MySQL 8.0+
- Redis 6.0+
- Maven 3.6+

### 1. 初始化数据库

```bash
mysql -u root -p < sql/init.sql
```

### 2. 修改配置

编辑 `src/main/resources/application.yml`，配置数据库和 Redis 连接：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/ticket_system?...
    username: your_username
    password: your_password
  redis:
    host: localhost
    port: 6379
    password: your_redis_password  # 无密码留空
```

### 3. 启动项目

```bash
mvn spring-boot:run
```

## 📡 接口说明

### 查询余票

```http
POST /api/ticket/query
Content-Type: application/json

{
  "startStation": "北京南",
  "endStation": "上海虹桥",
  "travelDate": "2025-06-01"
}
```

### 购票（乐观锁方案）

```http
POST /api/ticket/buy
Content-Type: application/json

{
  "userId": 1,
  "trainId": 1,
  "startStation": "北京南",
  "endStation": "上海虹桥",
  "travelDate": "2025-06-01",
  "seatType": 3
}
```

座位类型：`1`=商务座，`2`=一等座，`3`=二等座

### 查询实时库存

```http
GET /api/ticket/stock?trainId=1&travelDate=2025-06-01&seatType=3
```

## 📁 项目结构

```
ticket-system/
├── sql/
│   └── init.sql              # 建表语句 + 测试数据
└── src/main/java/com/ticket/
    ├── controller/
    │   └── TicketController  # REST 接口
    ├── service/impl/
    │   ├── TicketPurchaseServiceImpl  # 三种购票方案实现
    │   └── TicketQueryServiceImpl     # 余票查询（Redis缓存）
    ├── entity/               # 数据库实体
    ├── mapper/               # MyBatis Plus Mapper
    ├── dto/                  # 请求/响应对象
    ├── common/               # 枚举、通用响应
    └── config/               # Redis、MyBatis Plus 配置
```

## 🐛 Bug 修复记录（相较于原始版本）

| 编号 | 问题描述 | 修复方案 |
|------|----------|----------|
| #1 | `buyTicketWithRedisLock` 双重扣减Redis库存 | 拆分独立DB事务方法 `doExecutePurchaseInTransaction()`，不重复扣缓存 |
| #2 | 同类内部调用 `buyTicket()` 导致 `@Transactional` 失效 | 将DB操作内聚到独立事务方法 |
| #3 | 订单号用时间戳+截UUID，高并发下碰撞风险 | 改用雪花算法 `IdUtil.getSnowflake()` |
| #4 | `TicketQueryServiceImpl` 中 `Integer` 用 `==` 比较 | 改为 `.equals()` |

## 📌 待改进方向

- [ ] 接入 Spring Security / JWT 实现用户鉴权
- [ ] 座位位图查询走 MySQL 全表扫描，可考虑缓存预热 + 分片索引
- [ ] 引入消息队列（RocketMQ）做异步订单处理
- [ ] 添加订单超时自动取消机制

## 📄 License

MIT License
