package com.ticket.service;

import com.ticket.dto.BuyTicketRequest;
import com.ticket.dto.OrderVO;

public interface TicketPurchaseService {
    
    OrderVO buyTicket(BuyTicketRequest request);
    
    OrderVO buyTicketWithRedisLock(BuyTicketRequest request);
    
    OrderVO buyTicketWithOptimisticLock(BuyTicketRequest request);
}
