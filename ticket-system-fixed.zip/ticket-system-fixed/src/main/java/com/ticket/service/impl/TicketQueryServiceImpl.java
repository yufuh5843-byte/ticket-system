package com.ticket.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ticket.common.SeatTypeEnum;
import com.ticket.dto.TicketAvailableVO;
import com.ticket.dto.TicketQueryRequest;
import com.ticket.entity.Seat;
import com.ticket.entity.Train;
import com.ticket.entity.TrainStation;
import com.ticket.mapper.SeatMapper;
import com.ticket.mapper.TrainMapper;
import com.ticket.mapper.TrainStationMapper;
import com.ticket.service.TicketQueryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class TicketQueryServiceImpl implements TicketQueryService {

    private final TrainMapper trainMapper;
    private final TrainStationMapper trainStationMapper;
    private final SeatMapper seatMapper;
    private final StringRedisTemplate stringRedisTemplate;

    private static final String STOCK_CACHE_KEY_PREFIX = "ticket:stock:";
    private static final long CACHE_EXPIRE_HOURS = 2;

    @Override
    public List<TicketAvailableVO> queryAvailableTickets(TicketQueryRequest request) {
        log.info("查询余票：出发站={}, 到达站={}, 日期={}", 
                request.getStartStation(), request.getEndStation(), request.getTravelDate());

        List<Train> trains = trainMapper.selectByRoute(request.getStartStation(), request.getEndStation());
        
        if (trains.isEmpty()) {
            return new ArrayList<>();
        }

        List<TicketAvailableVO> result = new ArrayList<>();
        
        for (Train train : trains) {
            List<TrainStation> stations = trainStationMapper.selectByTrainId(train.getId());
            
            TrainStation startStationInfo = null;
            TrainStation endStationInfo = null;
            
            for (TrainStation station : stations) {
                if (request.getStartStation().equals(station.getStationName())) {
                    startStationInfo = station;
                }
                if (request.getEndStation().equals(station.getStationName())) {
                    endStationInfo = station;
                }
            }
            
            if (startStationInfo == null || endStationInfo == null) {
                continue;
            }

            int segmentMask = calculateSegmentMask(startStationInfo.getStationIndex(), 
                    endStationInfo.getStationIndex());

            for (SeatTypeEnum seatType : SeatTypeEnum.values()) {
                TicketAvailableVO vo = buildTicketAvailableVO(train, request, seatType, 
                        startStationInfo, endStationInfo, segmentMask);
                if (vo.getAvailableCount() > 0) {
                    result.add(vo);
                }
            }
        }
        
        log.info("查询到 {} 个可选车次座位类型", result.size());
        return result;
    }

    @Override
    public Integer getAvailableStockFromCache(Long trainId, String travelDate, Integer seatType) {
        String cacheKey = buildStockCacheKey(trainId, travelDate, seatType);
        
        String stockStr = stringRedisTemplate.opsForValue().get(cacheKey);
        
        if (StrUtil.isNotBlank(stockStr)) {
            log.debug("从缓存获取库存：trainId={}, stock={}", trainId, stockStr);
            return Integer.parseInt(stockStr);
        }

        List<Seat> seats = seatMapper.selectByTrainAndType(trainId, seatType);
        int availableCount = seats.size();
        
        stringRedisTemplate.opsForValue().set(cacheKey, String.valueOf(availableCount), 
                CACHE_EXPIRE_HOURS, TimeUnit.HOURS);
        
        log.info("缓存库存：trainId={}, seatType={}, stock={}", trainId, seatType, availableCount);
        return availableCount;
    }

    private TicketAvailableVO buildTicketAvailableVO(Train train, TicketQueryRequest request,
                                                      SeatTypeEnum seatType,
                                                      TrainStation startStationInfo,
                                                      TrainStation endStationInfo,
                                                      int segmentMask) {
        TicketAvailableVO vo = new TicketAvailableVO();
        vo.setTrainId(train.getId());
        vo.setTrainCode(train.getTrainCode());
        vo.setStartStation(request.getStartStation());
        vo.setEndStation(request.getEndStation());
        vo.setStartTime(train.getStartTime());
        vo.setEndTime(train.getEndTime());
        vo.setTravelDate(request.getTravelDate());
        vo.setSeatType(seatType.getCode());
        vo.setSeatTypeName(seatType.getName());

        Integer cachedStock = getAvailableStockFromCache(train.getId(), 
                request.getTravelDate().toString(), seatType.getCode());
        vo.setAvailableCount(cachedStock);

        BigDecimal price = calculatePrice(startStationInfo.getStationIndex(), 
                endStationInfo.getStationIndex(), seatType.getCode());
        vo.setPrice(price);

        int duration = calculateDuration(startStationInfo.getDepartTime(), 
                endStationInfo.getArriveTime());
        vo.setTotalDuration(duration);
        
        return vo;
    }

    private int calculateSegmentMask(int startIndex, int endIndex) {
        int mask = 0;
        for (int i = startIndex; i < endIndex; i++) {
            mask |= (1 << (i - 1));
        }
        return mask;
    }

    private BigDecimal calculatePrice(int startIndex, int endIndex, Integer seatType) {
        int segments = endIndex - startIndex;
        BigDecimal basePrice = BigDecimal.valueOf(50);
        BigDecimal price = basePrice.multiply(BigDecimal.valueOf(segments));
        
        if (SeatTypeEnum.BUSINESS.getCode().equals(seatType)) {
            price = price.multiply(BigDecimal.valueOf(2.5));
        } else if (SeatTypeEnum.FIRST_CLASS.getCode().equals(seatType)) {
            price = price.multiply(BigDecimal.valueOf(1.5));
        }
        
        return price.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    private int calculateDuration(LocalTime startTime, LocalTime endTime) {
        if (startTime == null || endTime == null) {
            return 0;
        }
        return (int) Duration.between(startTime, endTime).toMinutes();
    }

    private String buildStockCacheKey(Long trainId, String travelDate, Integer seatType) {
        return STOCK_CACHE_KEY_PREFIX + trainId + ":" + travelDate + ":" + seatType;
    }
}
