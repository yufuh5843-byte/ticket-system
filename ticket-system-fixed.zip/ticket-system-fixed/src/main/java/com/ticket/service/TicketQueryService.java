package com.ticket.service;

import com.ticket.dto.TicketAvailableVO;
import com.ticket.dto.TicketQueryRequest;
import java.util.List;

public interface TicketQueryService {
    
    List<TicketAvailableVO> queryAvailableTickets(TicketQueryRequest request);
    
    Integer getAvailableStockFromCache(Long trainId, String travelDate, Integer seatType);
}
