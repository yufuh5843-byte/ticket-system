package com.ticket.service.impl;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ticket.common.OrderStatusEnum;
import com.ticket.common.SeatTypeEnum;
import com.ticket.dto.BuyTicketRequest;
import com.ticket.dto.OrderVO;
import com.ticket.entity.Order;
import com.ticket.entity.Seat;
import com.ticket.entity.Train;
import com.ticket.entity.TrainStation;
import com.ticket.mapper.OrderMapper;
import com.ticket.mapper.SeatMapper;
import com.ticket.mapper.TrainMapper;
import com.ticket.mapper.TrainStationMapper;
import com.ticket.service.TicketPurchaseService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
@Service
@RequiredArgsConstructor
public class TicketPurchaseServiceImpl implements TicketPurchaseService {

    private final TrainMapper trainMapper;
    private final TrainStationMapper trainStationMapper;
    private final SeatMapper seatMapper;
    private final OrderMapper orderMapper;
    private final StringRedisTemplate stringRedisTemplate;

    // 雪花算法，保证高并发下订单号全局唯一（原版用时间戳截UUID，高并发下有碰撞风险）
    private static final Snowflake SNOWFLAKE = IdUtil.getSnowflake(1, 1);

    private static final String STOCK_CACHE_KEY_PREFIX = "ticket:stock:";
    private static final String LOCK_KEY_PREFIX = "ticket:lock:";
    private static final long LOCK_EXPIRE_TIME = 10;
    private static final int MAX_RETRY_TIMES = 3;

    private static final String LUA_DECREMENT_STOCK =
            "local key = KEYS[1]\n" +
            "local current = tonumber(redis.call('GET', key) or '0')\n" +
            "if current >= 1 then\n" +
            "    redis.call('DECRBY', key, 1)\n" +
            "    return 1\n" +
            "else\n" +
            "    return 0\n" +
            "end";

    /**
     * 方案一：乐观锁单次购票
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public OrderVO buyTicket(BuyTicketRequest request) {
        log.info("========== 开始购票（乐观锁单次）==========");
        Train train = validateTrain(request.getTrainId());
        TrainStation[] stations = validateAndGetStations(request);
        int segmentMask = calculateSegmentMask(stations[0].getStationIndex(), stations[1].getStationIndex());

        Seat seat = seatMapper.selectAvailableSeat(request.getTrainId(), request.getSeatType(), segmentMask);
        if (seat == null) throw new RuntimeException("该区间已无余票");

        int updated = seatMapper.occupySegmentWithOptimisticLock(seat.getId(), seat.getVersion(), segmentMask);
        if (updated == 0) throw new RuntimeException("购票失败，请重试");

        Order order = buildAndSaveOrder(request, train, seat, stations[0], stations[1]);
        decrementStockCache(request.getTrainId(), request.getTravelDate().toString(), request.getSeatType());
        log.info("购票成功（乐观锁）：orderNo={}", order.getOrderNo());
        return convertToOrderVO(order);
    }

    /**
     * 方案二：Redis 分布式锁购票
     *
     * BUG修复说明：
     * [原版Bug] buyTicketWithRedisLock() 先在Redis扣一次库存，
     *           再调用 buyTicket()，buyTicket() 内部又扣一次，导致双重扣减。
     * [修复方案] Redis锁方案内部调用独立的 doExecutePurchaseInTransaction()，
     *           该方法只做DB操作，不重复扣减Redis缓存。
     *
     * [原版Bug] 同类内部 this.buyTicket() 调用无法触发Spring事务代理，
     *           导致DB操作没有事务保护。
     * [修复方案] 将DB操作内聚到独立的 @Transactional 方法中。
     */
    @Override
    public OrderVO buyTicketWithRedisLock(BuyTicketRequest request) {
        log.info("========== 使用Redis分布式锁购票 ==========");
        String lockKey = LOCK_KEY_PREFIX + request.getTrainId() + ":" + request.getSeatType();
        String lockValue = IdUtil.simpleUUID();
        boolean locked = false;
        try {
            locked = tryLock(lockKey, lockValue);
            if (!locked) throw new RuntimeException("系统繁忙，请稍后重试");

            // Lua原子扣减Redis库存，快速拦截无库存请求
            String stockKey = buildStockCacheKey(request.getTrainId(),
                    request.getTravelDate().toString(), request.getSeatType());
            DefaultRedisScript<Long> script = new DefaultRedisScript<>(LUA_DECREMENT_STOCK, Long.class);
            Long result = stringRedisTemplate.execute(script, Collections.singletonList(stockKey));
            if (result == null || result == 0) throw new RuntimeException("余票不足");

            // 只走DB事务，不重复扣Redis缓存
            return doExecutePurchaseInTransaction(request);

        } catch (DataAccessException e) {
            log.error("Redis操作异常", e);
            throw new RuntimeException("系统异常，请稍后重试");
        } finally {
            if (locked) releaseLock(lockKey, lockValue);
        }
    }

    /**
     * 方案三：乐观锁 + 多候选位重试
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public OrderVO buyTicketWithOptimisticLock(BuyTicketRequest request) {
        log.info("========== 乐观锁+重试购票 ==========");
        Train train = validateTrain(request.getTrainId());
        TrainStation[] stations = validateAndGetStations(request);
        int segmentMask = calculateSegmentMask(stations[0].getStationIndex(), stations[1].getStationIndex());

        for (int retry = 0; retry < MAX_RETRY_TIMES; retry++) {
            List<Seat> candidates = findAvailableSeats(request.getTrainId(), request.getSeatType(), segmentMask, 5);
            if (candidates.isEmpty()) throw new RuntimeException("该区间已无余票");

            for (Seat seat : candidates) {
                int updated = seatMapper.occupySegmentWithOptimisticLock(seat.getId(), seat.getVersion(), segmentMask);
                if (updated > 0) {
                    Order order = buildAndSaveOrder(request, train, seat, stations[0], stations[1]);
                    decrementStockCache(request.getTrainId(), request.getTravelDate().toString(), request.getSeatType());
                    log.info("购票成功（乐观锁重试）：orderNo={}, retry={}", order.getOrderNo(), retry);
                    return convertToOrderVO(order);
                }
            }
            try {
                Thread.sleep(30L + new Random().nextInt(70));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("购票被中断");
            }
        }
        throw new RuntimeException("购票失败，系统繁忙请稍后重试");
    }

    /**
     * Redis锁方案专用：只做DB座位占用+订单创建，不扣Redis缓存（外层已扣）
     */
    @Transactional(rollbackFor = Exception.class)
    public OrderVO doExecutePurchaseInTransaction(BuyTicketRequest request) {
        Train train = validateTrain(request.getTrainId());
        TrainStation[] stations = validateAndGetStations(request);
        int segmentMask = calculateSegmentMask(stations[0].getStationIndex(), stations[1].getStationIndex());

        Seat seat = seatMapper.selectAvailableSeat(request.getTrainId(), request.getSeatType(), segmentMask);
        if (seat == null) throw new RuntimeException("该区间已无余票");

        int updated = seatMapper.occupySegmentWithOptimisticLock(seat.getId(), seat.getVersion(), segmentMask);
        if (updated == 0) throw new RuntimeException("购票失败，请重试");

        Order order = buildAndSaveOrder(request, train, seat, stations[0], stations[1]);
        return convertToOrderVO(order);
    }

    private Train validateTrain(Long trainId) {
        Train train = trainMapper.selectById(trainId);
        if (train == null || train.getStatus() != 1) throw new RuntimeException("车次不存在或已停运");
        return train;
    }

    private TrainStation[] validateAndGetStations(BuyTicketRequest request) {
        TrainStation start = trainStationMapper.selectByTrainAndStation(request.getTrainId(), request.getStartStation());
        TrainStation end = trainStationMapper.selectByTrainAndStation(request.getTrainId(), request.getEndStation());
        if (start == null || end == null) throw new RuntimeException("站点信息错误");
        if (start.getStationIndex() >= end.getStationIndex()) throw new RuntimeException("出发站必须在到达站之前");
        return new TrainStation[]{start, end};
    }

    private List<Seat> findAvailableSeats(Long trainId, Integer seatType, int segmentMask, int limit) {
        LambdaQueryWrapper<Seat> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Seat::getTrainId, trainId)
               .eq(Seat::getSeatType, seatType)
               .apply("(seat_segments & {0}) = 0", segmentMask)
               .last("LIMIT " + limit);
        return seatMapper.selectList(wrapper);
    }

    /**
     * 计算站段位图掩码
     * station_index 从1开始，bit位从0开始
     * 例：startIndex=1, endIndex=3 → 占用 bit0、bit1 → mask=0b011=3
     */
    private int calculateSegmentMask(int startIndex, int endIndex) {
        int mask = 0;
        for (int i = startIndex; i < endIndex; i++) {
            mask |= (1 << (i - 1));
        }
        return mask;
    }

    private Order buildAndSaveOrder(BuyTicketRequest request, Train train, Seat seat,
                                    TrainStation startStation, TrainStation endStation) {
        Order order = new Order();
        // 雪花算法生成订单号，高并发安全（原版时间戳+截UUID有碰撞风险）
        order.setOrderNo("TK" + SNOWFLAKE.nextIdStr());
        order.setUserId(request.getUserId());
        order.setTrainId(train.getId());
        order.setTrainCode(train.getTrainCode());
        order.setSeatId(seat.getId());
        order.setCarriageNo(seat.getCarriageNo());
        order.setSeatNo(seat.getSeatNo());
        order.setSeatType(seat.getSeatType());
        order.setStartStation(request.getStartStation());
        order.setEndStation(request.getEndStation());
        order.setStartStationIndex(startStation.getStationIndex());
        order.setEndStationIndex(endStation.getStationIndex());
        order.setTravelDate(request.getTravelDate());
        order.setPrice(calculatePrice(startStation.getStationIndex(), endStation.getStationIndex(), seat.getSeatType()));
        order.setStatus(OrderStatusEnum.UNPAID.getCode());
        order.setCreateTime(LocalDateTime.now());
        orderMapper.insert(order);
        return order;
    }

    private BigDecimal calculatePrice(int startIndex, int endIndex, Integer seatType) {
        int segments = endIndex - startIndex;
        BigDecimal price = BigDecimal.valueOf(50).multiply(BigDecimal.valueOf(segments));
        if (SeatTypeEnum.BUSINESS.getCode().equals(seatType)) {
            price = price.multiply(BigDecimal.valueOf(2.5));
        } else if (SeatTypeEnum.FIRST_CLASS.getCode().equals(seatType)) {
            price = price.multiply(BigDecimal.valueOf(1.5));
        }
        return price.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    private boolean tryLock(String lockKey, String lockValue) {
        Boolean ok = stringRedisTemplate.opsForValue()
                .setIfAbsent(lockKey, lockValue, LOCK_EXPIRE_TIME, TimeUnit.SECONDS);
        return Boolean.TRUE.equals(ok);
    }

    private void releaseLock(String lockKey, String lockValue) {
        // Lua保证「判断+删除」原子性，防止误删他人持有的锁
        String lua = "if redis.call('GET', KEYS[1]) == ARGV[1] then " +
                     "    return redis.call('DEL', KEYS[1]) " +
                     "else return 0 end";
        DefaultRedisScript<Long> script = new DefaultRedisScript<>(lua, Long.class);
        stringRedisTemplate.execute(script, Collections.singletonList(lockKey), lockValue);
    }

    private void decrementStockCache(Long trainId, String travelDate, Integer seatType) {
        stringRedisTemplate.opsForValue().decrement(buildStockCacheKey(trainId, travelDate, seatType));
    }

    private String buildStockCacheKey(Long trainId, String travelDate, Integer seatType) {
        return STOCK_CACHE_KEY_PREFIX + trainId + ":" + travelDate + ":" + seatType;
    }

    private OrderVO convertToOrderVO(Order order) {
        OrderVO vo = new OrderVO();
        vo.setOrderId(order.getId());
        vo.setOrderNo(order.getOrderNo());
        vo.setTrainCode(order.getTrainCode());
        vo.setCarriageNo(order.getCarriageNo());
        vo.setSeatNo(order.getSeatNo());
        vo.setSeatTypeName(SeatTypeEnum.getNameByCode(order.getSeatType()));
        vo.setStartStation(order.getStartStation());
        vo.setEndStation(order.getEndStation());
        vo.setTravelDate(order.getTravelDate());
        vo.setPrice(order.getPrice());
        vo.setStatus(order.getStatus());
        vo.setStatusName(OrderStatusEnum.getNameByCode(order.getStatus()));
        vo.setCreateTime(order.getCreateTime());
        return vo;
    }
}
