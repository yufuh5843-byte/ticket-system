package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("t_seat")
public class Seat {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long trainId;
    private Integer carriageNo;
    private String seatNo;
    private Integer seatType;
    
    private Integer seatSegments;
    
    @Version
    private Integer version;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
