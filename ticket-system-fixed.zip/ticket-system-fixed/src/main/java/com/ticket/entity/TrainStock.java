package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("t_train_stock")
public class TrainStock {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long trainId;
    private LocalDate travelDate;
    private Integer seatType;
    private Integer totalStock;
    private Integer availableStock;
    
    @Version
    private Integer version;
    
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
