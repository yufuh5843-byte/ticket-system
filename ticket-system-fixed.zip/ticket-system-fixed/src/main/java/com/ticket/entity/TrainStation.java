package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@TableName("t_train_station")
public class TrainStation {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long trainId;
    private String stationName;
    private Integer stationIndex;
    private LocalTime arriveTime;
    private LocalTime departTime;
    private Integer stayMinutes;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
