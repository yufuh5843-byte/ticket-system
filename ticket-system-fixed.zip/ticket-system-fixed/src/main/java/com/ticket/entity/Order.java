package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("t_order")
public class Order {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String orderNo;
    private Long userId;
    private Long trainId;
    private String trainCode;
    private Long seatId;
    private Integer carriageNo;
    private String seatNo;
    private Integer seatType;
    private String startStation;
    private String endStation;
    private Integer startStationIndex;
    private Integer endStationIndex;
    private LocalDate travelDate;
    private BigDecimal price;
    private Integer status;
    private LocalDateTime payTime;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
