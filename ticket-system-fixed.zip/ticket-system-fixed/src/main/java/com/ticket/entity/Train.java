package com.ticket.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Data
@TableName("t_train")
public class Train {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String trainCode;
    private Integer trainType;
    private String startStation;
    private String endStation;
    private LocalTime startTime;
    private LocalTime endTime;
    private Integer totalSeats;
    private Integer status;
    private LocalDateTime saleStartTime;
    private LocalDateTime saleEndTime;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
}
