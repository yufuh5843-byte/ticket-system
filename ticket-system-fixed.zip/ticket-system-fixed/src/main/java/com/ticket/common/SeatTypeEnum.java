package com.ticket.common;

import lombok.Getter;

@Getter
public enum SeatTypeEnum {
    BUSINESS(1, "商务座"),
    FIRST_CLASS(2, "一等座"),
    SECOND_CLASS(3, "二等座");

    private final Integer code;
    private final String name;

    SeatTypeEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public static String getNameByCode(Integer code) {
        for (SeatTypeEnum type : values()) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "未知";
    }
}
