package com.ticket.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ticket.entity.Seat;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import java.util.List;

@Mapper
public interface SeatMapper extends BaseMapper<Seat> {

    @Select("SELECT * FROM t_seat WHERE train_id = #{trainId} AND seat_type = #{seatType}")
    List<Seat> selectByTrainAndType(@Param("trainId") Long trainId, @Param("seatType") Integer seatType);

    @Update("UPDATE t_seat SET seat_segments = seat_segments | #{segmentMask}, version = version + 1 " +
            "WHERE id = #{id} AND version = #{version} AND (seat_segments & #{segmentMask}) = 0")
    int occupySegmentWithOptimisticLock(@Param("id") Long id, 
                                        @Param("version") Integer version,
                                        @Param("segmentMask") Integer segmentMask);

    @Select("SELECT * FROM t_seat WHERE train_id = #{trainId} AND seat_type = #{seatType} " +
            "AND (seat_segments & #{segmentMask}) = 0 LIMIT 1")
    Seat selectAvailableSeat(@Param("trainId") Long trainId, 
                             @Param("seatType") Integer seatType,
                             @Param("segmentMask") Integer segmentMask);
}
