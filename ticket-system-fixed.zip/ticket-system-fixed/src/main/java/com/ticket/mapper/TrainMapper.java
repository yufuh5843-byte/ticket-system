package com.ticket.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ticket.entity.Train;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface TrainMapper extends BaseMapper<Train> {

    @Select("SELECT t.* FROM t_train t " +
            "INNER JOIN t_train_station ts1 ON t.id = ts1.train_id " +
            "INNER JOIN t_train_station ts2 ON t.id = ts2.train_id " +
            "WHERE ts1.station_name = #{startStation} " +
            "AND ts2.station_name = #{endStation} " +
            "AND ts1.station_index < ts2.station_index " +
            "AND t.status = 1")
    List<Train> selectByRoute(@Param("startStation") String startStation, 
                              @Param("endStation") String endStation);
}
