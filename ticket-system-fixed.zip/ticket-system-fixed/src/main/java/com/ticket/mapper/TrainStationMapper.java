package com.ticket.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ticket.entity.TrainStation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface TrainStationMapper extends BaseMapper<TrainStation> {

    @Select("SELECT * FROM t_train_station WHERE train_id = #{trainId} ORDER BY station_index")
    List<TrainStation> selectByTrainId(@Param("trainId") Long trainId);

    @Select("SELECT * FROM t_train_station WHERE train_id = #{trainId} AND station_name = #{stationName}")
    TrainStation selectByTrainAndStation(@Param("trainId") Long trainId, 
                                         @Param("stationName") String stationName);
}
