package com.ticket.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ticket.entity.TrainStock;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface TrainStockMapper extends BaseMapper<TrainStock> {

    @Update("UPDATE t_train_stock SET available_stock = available_stock - 1, version = version + 1 " +
            "WHERE train_id = #{trainId} AND travel_date = #{travelDate} AND seat_type = #{seatType} " +
            "AND available_stock > 0 AND version = #{version}")
    int decrementStockWithOptimisticLock(@Param("trainId") Long trainId,
                                         @Param("travelDate") String travelDate,
                                         @Param("seatType") Integer seatType,
                                         @Param("version") Integer version);
}
