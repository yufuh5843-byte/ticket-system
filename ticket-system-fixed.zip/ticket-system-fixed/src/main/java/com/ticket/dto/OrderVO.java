package com.ticket.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class OrderVO {
    private Long orderId;
    private String orderNo;
    private String trainCode;
    private Integer carriageNo;
    private String seatNo;
    private String seatTypeName;
    private String startStation;
    private String endStation;
    private LocalDate travelDate;
    private BigDecimal price;
    private Integer status;
    private String statusName;
    private LocalDateTime createTime;
}
