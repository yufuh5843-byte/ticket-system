package com.ticket.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class TicketAvailableVO {
    private Long trainId;
    private String trainCode;
    private String startStation;
    private String endStation;
    private LocalTime startTime;
    private LocalTime endTime;
    private LocalDate travelDate;
    private Integer seatType;
    private String seatTypeName;
    private Integer availableCount;
    private BigDecimal price;
    private Integer totalDuration;
}
