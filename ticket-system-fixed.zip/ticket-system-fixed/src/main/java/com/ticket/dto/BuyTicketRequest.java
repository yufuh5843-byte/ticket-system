package com.ticket.dto;

import lombok.Data;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
public class BuyTicketRequest {
    @NotNull(message = "用户ID不能为空")
    private Long userId;
    
    @NotNull(message = "车次ID不能为空")
    private Long trainId;
    
    @NotNull(message = "座位类型不能为空")
    private Integer seatType;
    
    @NotBlank(message = "出发站不能为空")
    private String startStation;
    
    @NotBlank(message = "到达站不能为空")
    private String endStation;
    
    @NotNull(message = "出行日期不能为空")
    private LocalDate travelDate;
}
