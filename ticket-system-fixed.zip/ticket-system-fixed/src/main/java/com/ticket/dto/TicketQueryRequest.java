package com.ticket.dto;

import lombok.Data;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
public class TicketQueryRequest {
    @NotBlank(message = "出发站不能为空")
    private String startStation;
    
    @NotBlank(message = "到达站不能为空")
    private String endStation;
    
    @NotNull(message = "出行日期不能为空")
    private LocalDate travelDate;
}
