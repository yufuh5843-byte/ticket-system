package com.ticket.controller;

import com.ticket.common.Result;
import com.ticket.dto.BuyTicketRequest;
import com.ticket.dto.OrderVO;
import com.ticket.dto.TicketAvailableVO;
import com.ticket.dto.TicketQueryRequest;
import com.ticket.service.TicketPurchaseService;
import com.ticket.service.TicketQueryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/ticket")
@RequiredArgsConstructor
public class TicketController {

    private final TicketQueryService ticketQueryService;
    private final TicketPurchaseService ticketPurchaseService;

    @PostMapping("/query")
    public Result<List<TicketAvailableVO>> queryAvailableTickets(
            @Validated @RequestBody TicketQueryRequest request) {
        log.info("查询余票请求：{}", request);
        List<TicketAvailableVO> tickets = ticketQueryService.queryAvailableTickets(request);
        return Result.success(tickets);
    }

    @GetMapping("/stock")
    public Result<Integer> getAvailableStock(
            @RequestParam Long trainId,
            @RequestParam String travelDate,
            @RequestParam Integer seatType) {
        log.info("查询库存：trainId={}, travelDate={}, seatType={}", trainId, travelDate, seatType);
        Integer stock = ticketQueryService.getAvailableStockFromCache(trainId, travelDate, seatType);
        return Result.success(stock);
    }

    @PostMapping("/buy")
    public Result<OrderVO> buyTicket(@Validated @RequestBody BuyTicketRequest request) {
        log.info("购票请求：{}", request);
        OrderVO order = ticketPurchaseService.buyTicket(request);
        return Result.success(order);
    }

    @PostMapping("/buy-with-lock")
    public Result<OrderVO> buyTicketWithRedisLock(@Validated @RequestBody BuyTicketRequest request) {
        log.info("Redis分布式锁购票请求：{}", request);
        OrderVO order = ticketPurchaseService.buyTicketWithRedisLock(request);
        return Result.success(order);
    }

    @PostMapping("/buy-with-optimistic")
    public Result<OrderVO> buyTicketWithOptimisticLock(@Validated @RequestBody BuyTicketRequest request) {
        log.info("乐观锁购票请求：{}", request);
        OrderVO order = ticketPurchaseService.buyTicketWithOptimisticLock(request);
        return Result.success(order);
    }
}
